import kivy

print(kivy. __version__)